document.write('<header class="header">');
document.write('<nav class=" navbar-light bg-light">');
document.write('<div class="container-fluid ">');

document.write('<div class="row">');
document.write('<div class="col-3 mx-5 font-weight-bold font-italic  h2">ISID</div>');
document.write('<div class="col-3 ml-auto"></div>');
document.write('<div class="col-auto my-2 h5 ">li9876</div>');
document.write('<div class="col-auto my-2 h5">山田太郎</div>');
document.write('<div class="ml-auto ">');
document.write('<a href="start.html ">');
document.write('<input class="btn btn btn-primary my-1 mx-1" type="submit" value="ログアウト" /></a>');
document.write('</div>');
document.write('</div>');
document.write('</div>');
document.write('</nav>');




document.write('<nav class=" navbar-light bg-primary  ">');
document.write('<div class="text-center ">');
document.write('<a class="navbar-brand  h3 text-white  " href="V200_01EnqueteListView.html">アンケート一覧</a>');
document.write('<div class="navbar-brand  h3 text-white">|</div>');
document.write('<a class="navbar-brand  h3 text-white" href="V201_01EnqueteEditView.html">アンケート作成</a>');

document.write('</div>');
document.write('<hr>');
document.write('</nav>');
document.write('</header>');