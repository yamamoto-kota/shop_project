package jp.co.isid.advtraining.VM;

import jp.co.isid.advtraining.entity.Choice;


public class ChoiceVM {


	private Choice choice;
	private Boolean Answered;
//	private ChoiceAnswer choiceAnswer;
	public Choice getChoice() {
		return choice;
	}
	public void setChoice(Choice choice) {
		this.choice = choice;
	}
	public Boolean getAnswered() {
		return Answered;
	}
	public void setAnswered(Boolean answered) {
		Answered = answered;
	}







}
