package jp.co.isid.advtraining.dao;

import java.util.List;

import org.seasar.doma.Dao;
import org.seasar.doma.Select;

import jp.co.isid.advtraining.ConfigAutowireable;
import jp.co.isid.advtraining.entity.Enquete;

@Dao
@ConfigAutowireable
public interface EnqueteListDao {

	//未回答アンケート情報をリストで返却する。
	@Select
	 List<Enquete> noAnswerList(String esqId);

	//回答済みアンケート情報をリストで返却する。
	@Select
	 List<Enquete> completeAnswerList(String esqId);

	//実施前アンケート情報をリストで返却する。
	@Select
	 List<Enquete> beforeEnqueteList(String esqId) ;

	//実施中アンケート情報をリストで返却する。
	@Select
	 List<Enquete> startEnqueteList(String esqId);

	//実施完了アンケート情報をリストで返却する。
	@Select
	 List<Enquete> finishEnqueteList(String esqId);
}

