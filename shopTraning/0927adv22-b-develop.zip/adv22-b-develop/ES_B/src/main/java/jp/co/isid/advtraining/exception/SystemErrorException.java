package jp.co.isid.advtraining.exception;


public class SystemErrorException extends RuntimeException{
	//warningを回避するための宣言
	private static final long serialVersionUID = 1L;

	public SystemErrorException(){
	}
}
