select
  /*%expand*/*
from
  choice_answer
where
  choice_answer_id = /* choiceAnswerId */1
