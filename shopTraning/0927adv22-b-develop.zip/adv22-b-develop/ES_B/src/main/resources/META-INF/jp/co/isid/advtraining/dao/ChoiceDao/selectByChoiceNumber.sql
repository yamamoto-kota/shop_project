SELECT choice_number FROM choice
where choice_id= /* choiceId */1;