select
  /*%expand*/*
from
  choice
where
  choice_id = /* choiceId */1
