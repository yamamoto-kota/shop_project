select
  /*%expand*/*
from
  choice
where
  choice_id = /* choiceId */1
  and
  version = /* version */1
