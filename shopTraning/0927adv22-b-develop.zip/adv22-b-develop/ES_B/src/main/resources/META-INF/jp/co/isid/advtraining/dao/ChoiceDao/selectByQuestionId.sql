select
  /*%expand*/*
from
  choice
where
  question_id = /* questionId */1
order by choice_number asc