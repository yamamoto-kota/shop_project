select
  /*%expand*/*
from
  dept
order by dept_id asc