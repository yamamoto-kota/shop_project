select
  /*%expand*/*
from
  dept
where
  DEPT_ID = /* deptId */'a'
