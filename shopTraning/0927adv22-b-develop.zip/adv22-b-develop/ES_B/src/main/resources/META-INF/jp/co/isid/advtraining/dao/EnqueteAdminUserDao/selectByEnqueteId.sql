select
  /*%expand*/*
from
  enquete_admin_user
where
  enquete_id = /* enqueteId */1
