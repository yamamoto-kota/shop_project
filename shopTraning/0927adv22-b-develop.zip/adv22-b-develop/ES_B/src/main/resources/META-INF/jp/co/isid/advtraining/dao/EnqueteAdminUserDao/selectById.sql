SELECT
enquete_id,esq_id,delete_flag
FROM
enquete_admin_user
WHERE
enquete_id = /*enqueteId*/1
AND
esq_id = /*esqId*/'li9010';
