select
  /*%expand*/*
from
  enquete_answer
where
  enquete_answer_id = /* enqueteAnswerId */1
