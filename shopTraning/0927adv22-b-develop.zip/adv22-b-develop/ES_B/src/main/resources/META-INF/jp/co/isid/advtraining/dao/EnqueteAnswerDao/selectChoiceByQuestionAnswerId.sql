SELECT choice_answer_id,question_answer_id,choice_id
FROM choice_answer
WHERE question_answer_id=/*questionAnswerId*/1;