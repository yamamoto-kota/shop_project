SELECT choice_id,question_id,choice_number,choice_text,version
FROM choice
WHERE question_id=/*questionId*/1;