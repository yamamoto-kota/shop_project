SELECT enquete_answer_id,enquete_id,esq_id,answer_date
FROM enquete_answer
WHERE enquete_id=/*enqueteId*/1
AND esq_id=/*esqId*/1