SELECT enquete_id,enquete_name,enquete_state_id,create_user_id,create_date,start_date,finish_date,enquete_subtext,version
FROM enquete
WHERE enquete_id=/*enqueteId*/1