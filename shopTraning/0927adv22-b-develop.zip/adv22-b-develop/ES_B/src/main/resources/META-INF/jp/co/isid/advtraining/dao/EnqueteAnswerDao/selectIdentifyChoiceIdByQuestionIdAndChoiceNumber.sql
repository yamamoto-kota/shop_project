SELECT choice_id
FROM choice
WHERE question_id=/*questionId*/1
AND choice_number=/*choiceNumber*/1;