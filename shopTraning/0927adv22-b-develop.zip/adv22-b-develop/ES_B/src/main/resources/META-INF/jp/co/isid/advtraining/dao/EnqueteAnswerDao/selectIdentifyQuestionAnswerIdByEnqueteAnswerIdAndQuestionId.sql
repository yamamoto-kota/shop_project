SELECT question_answer_id
FROM question_answer
WHERE enquete_answer_id=/*enqueteAnswerId*/1
AND question_id=/*questionId*/1;