SELECT question_type_id
FROM question
WHERE enquete_id=/*enqueteId*/1
AND question_number=/*questionNumber*/1;