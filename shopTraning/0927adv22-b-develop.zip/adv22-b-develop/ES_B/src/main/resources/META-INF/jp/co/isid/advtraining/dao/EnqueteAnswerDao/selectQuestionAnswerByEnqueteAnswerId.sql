SELECT question_answer_id,enquete_answer_id,question_id,answer_text
FROM question_answer
WHERE enquete_answer_id=/*enqueteAnswerId*/1;