SELECT question_id,enquete_id,question_number,question_type_id,require_flag,question_text,question_subtext,version
FROM question
WHERE enquete_id=/*enqueteId*/1;