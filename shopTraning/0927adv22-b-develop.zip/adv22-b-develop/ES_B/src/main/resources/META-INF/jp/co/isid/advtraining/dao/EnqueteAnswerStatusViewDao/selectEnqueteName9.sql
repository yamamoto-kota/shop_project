SELECT enquete_name
FROM enquete
WHERE enquete_id=/*enqueteId*/1