select dept_id from enquete_dept 
where enquete_dept.enquete_id=/*enqueteId*/2
order by dept_id asc;