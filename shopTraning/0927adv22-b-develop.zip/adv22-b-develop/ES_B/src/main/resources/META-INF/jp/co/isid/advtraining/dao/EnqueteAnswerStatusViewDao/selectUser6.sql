SELECT count(esq_id) FROM esq_user 
WHERE dept_id=/*deptId*/1;