select
  /*%expand*/*
from
  enquete
where
  enquete_id = /* enqueteId */1
