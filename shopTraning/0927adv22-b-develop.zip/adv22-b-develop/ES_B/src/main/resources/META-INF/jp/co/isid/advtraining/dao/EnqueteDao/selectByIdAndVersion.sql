select
  /*%expand*/*
from
  enquete
where
  enquete_id = /* enqueteId */1
  and
  version = /* version */1
