select
  /*%expand*/*
from
  enquete_dept
where
  enquete_id = /* enqueteId */1
order by dept_id asc