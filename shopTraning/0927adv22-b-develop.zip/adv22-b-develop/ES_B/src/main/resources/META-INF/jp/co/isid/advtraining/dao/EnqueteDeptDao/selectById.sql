select
  /*%expand*/*
from
  enquete_dept
where
  enquete_id = /* enqueteId */1
  and
  dept_id = /* deptId */1
