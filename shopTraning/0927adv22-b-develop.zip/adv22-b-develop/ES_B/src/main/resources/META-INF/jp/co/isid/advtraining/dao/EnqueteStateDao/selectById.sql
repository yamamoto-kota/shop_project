select
  /*%expand*/*
from
  enquete_state
where
  enquete_state_id = /* enqueteStateId */1
