select
  /*%expand*/*
from
  esq_user
where
  esq_id = /* esqId */'a'
