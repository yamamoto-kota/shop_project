select
  /*%expand*/*
from
  question_answer
where
  question_answer_id = /* questionAnswerId */1
