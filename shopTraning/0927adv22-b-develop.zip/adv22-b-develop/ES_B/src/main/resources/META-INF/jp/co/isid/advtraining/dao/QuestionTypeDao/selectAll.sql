select
  /*%expand*/*
from
  question_type
order by question_type_id asc