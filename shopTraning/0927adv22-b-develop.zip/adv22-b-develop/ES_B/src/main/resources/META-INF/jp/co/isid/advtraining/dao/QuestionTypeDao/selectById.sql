select
  /*%expand*/*
from
  question_type
where
  question_type_id = /* questionTypeId */1
